#!/bin/sh
# ────────────────────────────────────────────────────────────────────
#  install_addon.sh
#  One-command installer for the Send to QNAP++ authentication-helper
#  Download Station add-on.
#
#  WHY A SHELL SCRIPT: Python is NOT installed on QNAP QTS by default —
#  it requires manually installing a Python3 package from the App
#  Center first. Every QTS system, on the other hand, already has
#  /bin/sh, tar, sed, find and grep built in. Using those means this
#  installer works immediately for anyone, with nothing to install first.
#
#  USAGE
#    1. Extract BOTH this script and the .addon file from
#       sendtoqnap_addon.zip into the same folder.
#    2. Copy that folder to your NAS (any folder, via SMB/SCP/etc).
#    3. SSH into the NAS logged in as an administrator account
#       (QNAP has no separate "root" — an admin account already has
#       full access, so no sudo/su is needed or used here).
#    4. Run:
#         sh install_addon.sh
#       (or point it at the file directly: sh install_addon.sh /path/to/file.addon)
#
#  FLAGS
#    --restart      Always restart Download Station after installing,
#                   without asking for confirmation first.
#    --no-restart   Never restart Download Station after installing.
#    (default: on a brand-new install, ASK before restarting — since it
#     will interrupt any downloads in progress. Updates to an already-
#     installed add-on skip the restart entirely; that has not been
#     observed to need one.)
# ────────────────────────────────────────────────────────────────────

# ──────────────────────────────
#  COLOR OUTPUT HELPERS
# ──────────────────────────────

RESET="$(printf '\033[0m')"
BOLD="$(printf '\033[1m')"
DIM="$(printf '\033[2m')"
RED="$(printf '\033[31m')"
GREEN="$(printf '\033[32m')"
YELLOW="$(printf '\033[33m')"
CYAN="$(printf '\033[36m')"

banner() {
    printf '\n'
    printf '%s%s  ────────────────────────────────────────────────────────────%s\n' "$BOLD" "$CYAN" "$RESET"
    printf '%s%s   %s%s\n' "$BOLD" "$CYAN" "$1" "$RESET"
    printf '%s%s  ────────────────────────────────────────────────────────────%s\n' "$BOLD" "$CYAN" "$RESET"
}

rule() {
    printf '%s  ────────────────────────────────────────────────────────────%s\n' "$CYAN" "$RESET"
}

info() { printf '  %s\n' "$1"; }
ok()   { printf '  %s✓%s %s\n' "$GREEN" "$RESET" "$1"; }
warn() { printf '  %s⚠%s  %s\n' "$YELLOW" "$RESET" "$1"; }
err()  { printf '  %s✗%s %s\n' "$RED" "$RESET" "$1"; }

fail() {
    printf '\n'
    err "$1"
    printf '\n'
    exit 1
}

# ──────────────────────────────
#  ELEVATION
#  Stock QTS has no sudo and no separate root account (an admin login
#  already is UID 0) — but many setups add sudo via Entware, and if it's
#  there, we should just use it rather than making you type it yourself.
# ──────────────────────────────

if [ "$(id -u)" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then
        echo "  [sudo] Elevated access required — re-running with sudo ..."
        exec sudo sh "$0" "$@"
    else
        fail "This needs elevated access, and no sudo was found on this NAS.
    Stock QTS has no separate root account, so either:
      • log out and SSH back in using an administrator account, or
      • install sudo via Entware (opkg install sudo) for a password
        prompt like this one, if you have Entware set up."
    fi
fi

# ──────────────────────────────
#  ARGUMENT PARSING
# ──────────────────────────────

ADDON_FILE=""
FORCE_RESTART=0
FORCE_NO_RESTART=0

for arg in "$@"; do
    case "$arg" in
        --restart)    FORCE_RESTART=1 ;;
        --no-restart) FORCE_NO_RESTART=1 ;;
        *)            ADDON_FILE="$arg" ;;
    esac
done

banner "SEND TO QNAP++  —  Add-on Installer"

# ──────────────────────────────
#  STEP 1 — FIND THE .addon FILE
# ──────────────────────────────

info "Looking for the .addon file ..."

if [ -z "$ADDON_FILE" ]; then
    COUNT=0
    for f in "$PWD"/*.addon; do
        [ -f "$f" ] || continue
        COUNT=$((COUNT + 1))
        ADDON_FILE="$f"
    done
    if [ "$COUNT" -gt 1 ]; then
        warn "Multiple .addon files found in this folder:"
        for f in "$PWD"/*.addon; do
            [ -f "$f" ] && info "    $f"
        done
        fail "Please run again naming the one you want:
      sh install_addon.sh /path/to/file.addon"
    fi
    if [ "$COUNT" -eq 0 ] && [ -n "$HOME" ]; then
        for f in "$HOME"/*.addon; do
            [ -f "$f" ] || continue
            ADDON_FILE="$f"
            break
        done
    fi
fi

if [ -z "$ADDON_FILE" ] || [ ! -f "$ADDON_FILE" ]; then
    fail "No .addon file found in this folder or your home folder.
    Extract it from sendtoqnap_addon.zip first, or run:
      sh install_addon.sh /path/to/file.addon"
fi

ok "Found: ${BOLD}$(basename "$ADDON_FILE")${RESET}"

# ──────────────────────────────
#  STEP 2 — READ THE ADD-ON'S OWN addon.json
# ──────────────────────────────

info "Reading the add-on's definition file ..."

TMPDIR=$(mktemp -d) || fail "Could not create a temp folder to inspect the .addon."
trap 'rm -rf "$TMPDIR"' EXIT

if ! tar -xf "$ADDON_FILE" -C "$TMPDIR" 2>/dev/null; then
    fail "Could not open $(basename "$ADDON_FILE") as an archive — is this a valid .addon file?"
fi

ADDON_JSON=$(find "$TMPDIR" -name "addon.json" | head -n 1)
if [ -z "$ADDON_JSON" ]; then
    fail "addon.json not found inside $(basename "$ADDON_FILE")."
fi

DOMAIN=$(sed -n 's/.*"domain"[ ]*:[ ]*"\([^"]*\)".*/\1/p' "$ADDON_JSON" | head -n 1)
NAME=$(sed -n 's/.*"name"[ ]*:[ ]*"\([^"]*\)".*/\1/p' "$ADDON_JSON" | head -n 1)

if [ -z "$DOMAIN" ]; then
    fail "Could not read the \"domain\" field from addon.json — cannot proceed."
fi

[ -z "$NAME" ] && NAME="$DOMAIN"
ok "Add-on: ${BOLD}${NAME}${RESET}  ${DIM}(${DOMAIN})${RESET}"

# ──────────────────────────────
#  STEP 3 — FIND DOWNLOAD STATION
# ──────────────────────────────

info "Locating Download Station ..."

QPKG_CONF="/etc/config/qpkg.conf"
DS_SBIN=""

# Tier 1 — QNAP's own canonical mechanism: every installed QPKG registers
# its real path in qpkg.conf, independent of volume label or QTS version.
if [ -f "$QPKG_CONF" ]; then
    INSTALL_PATH=$(/sbin/getcfg DownloadStation Install_Path -f "$QPKG_CONF" 2>/dev/null)
    if [ -n "$INSTALL_PATH" ] && [ -x "${INSTALL_PATH}/usr/sbin/ds-addon" ]; then
        DS_SBIN="${INSTALL_PATH}/usr/sbin"
    fi
fi

# Tier 2 — same mechanism, but in case the section isn't named exactly
# "DownloadStation" on some QTS version, find whichever section is.
if [ -z "$DS_SBIN" ] && [ -f "$QPKG_CONF" ]; then
    SECTION=$(grep -i '^\[.*download.*station.*\]' "$QPKG_CONF" | head -n 1 | tr -d '[]')
    if [ -n "$SECTION" ]; then
        INSTALL_PATH=$(/sbin/getcfg "$SECTION" Install_Path -f "$QPKG_CONF" 2>/dev/null)
        if [ -n "$INSTALL_PATH" ] && [ -x "${INSTALL_PATH}/usr/sbin/ds-addon" ]; then
            DS_SBIN="${INSTALL_PATH}/usr/sbin"
        fi
    fi
fi

# Tier 3 — genuine filesystem search, no volume name assumed. Only
# reached if qpkg.conf didn't have what we needed above.
if [ -z "$DS_SBIN" ]; then
    warn "qpkg.conf lookup didn't resolve it — searching installed packages ..."
    for QPKG_ROOT in /share/*/.qpkg; do
        [ -d "$QPKG_ROOT" ] || continue
        printf '.'
        FOUND=$(find "$QPKG_ROOT" -maxdepth 4 -type f -name "ds-addon" 2>/dev/null | head -n 1)
        if [ -n "$FOUND" ]; then
            DS_SBIN=$(dirname "$FOUND")
            break
        fi
    done
    printf '\n'
fi

if [ -z "$DS_SBIN" ]; then
    fail "Could not locate Download Station's ds-addon utility anywhere on this NAS.
    Is Download Station installed? Check the App Center."
fi

DS_ADDON="${DS_SBIN}/ds-addon"
ok "Found Download Station  →  ${DIM}${DS_SBIN}${RESET}"

# ──────────────────────────────
#  STEP 4 — NEW INSTALL OR UPDATE?
# ──────────────────────────────

if "$DS_ADDON" -a 2>/dev/null | grep -q "$DOMAIN"; then
    WAS_INSTALLED=1
    info "Status: ${BOLD}updating${RESET} an existing install"
else
    WAS_INSTALLED=0
    info "Status: ${BOLD}new install${RESET}"
fi

# ──────────────────────────────
#  STEP 5 — INSTALL + ENABLE
# ──────────────────────────────

banner "INSTALLING"

info "Installing (this replaces any older version) ..."
if ! "$DS_ADDON" -i "$ADDON_FILE" 1; then
    fail "Install failed — see the ds-addon output above."
fi
ok "Add-on installed."

info "Enabling ..."
if ! "$DS_ADDON" -e "$DOMAIN" 1; then
    fail "Enable failed — see the ds-addon output above."
fi
ok "Add-on enabled."

# ──────────────────────────────
#  STEP 6 — RESTART (new installs only, by default)
# ──────────────────────────────

SHOULD_RESTART=0
ASK_CONFIRM=0

if [ "$FORCE_RESTART" -eq 1 ]; then
    SHOULD_RESTART=1
elif [ "$FORCE_NO_RESTART" -eq 1 ]; then
    SHOULD_RESTART=0
elif [ "$WAS_INSTALLED" -eq 0 ]; then
    SHOULD_RESTART=1
    ASK_CONFIRM=1   # this is our own default guess, not something explicitly requested — confirm first
fi

DECLINED=0
if [ "$SHOULD_RESTART" -eq 1 ] && [ "$ASK_CONFIRM" -eq 1 ]; then
    printf '\n'
    warn "This is a brand-new install — Download Station usually needs a restart"
    warn "to register a brand-new add-on, but that WILL interrupt any downloads"
    warn "currently in progress."
    printf '  Restart Download Station now? (Y/n): '
    read -r RESP
    case "$RESP" in
        [nN]*)
            SHOULD_RESTART=0
            DECLINED=1
            ;;
    esac
fi

if [ "$SHOULD_RESTART" -eq 1 ]; then
    banner "RESTARTING DOWNLOAD STATION"
    info "New installs sometimes need this so Download Station registers the add-on."
    INIT_SCRIPT="/etc/init.d/DownloadStation.sh"
    if [ -x "$INIT_SCRIPT" ] && sh "$INIT_SCRIPT" restart >/dev/null 2>&1; then
        ok "Download Station restarted."
    else
        warn "Could not restart Download Station automatically on this QTS version."
        info "  Please restart it manually:"
        info "    App Center → Download Station → dropdown arrow → Stop → Start"
    fi
elif [ "$DECLINED" -eq 1 ]; then
    printf '\n'
    info "${DIM}Skipping restart, as you chose. If the add-on doesn't seem to work,${RESET}"
    info "${DIM}restart it manually later: App Center → Download Station → Stop → Start.${RESET}"
elif [ "$WAS_INSTALLED" -eq 1 ]; then
    printf '\n'
    info "${DIM}Skipping restart — this was an update to an already-installed add-on,${RESET}"
    info "${DIM}and updates have not been observed to need one. Use --restart to force one.${RESET}"
fi

# ──────────────────────────────
#  DONE
# ──────────────────────────────

printf '\n'
rule
ok "${BOLD}Done!${RESET}"
info "Go back to the Firefox extension → ${BOLD}Send To Qnap++${RESET} → Settings"
info "and confirm the ${BOLD}Auth Helper${RESET} shows as ${GREEN}${BOLD}Enabled${RESET}."
rule
