Send To Qnap++ Authentication Helper Add-On for Qnap Download Station

-[ What is this? ]-
An optional Qnap Download Station addon that enables authenticated downloads from premium file hosting sites like Gofile, Mega, MediaFire, and 30+ others.

-[ Do I need this? ]-
No, it's completely optional! 

The front-end Firefox extension works fine for most sites without this qnap addon-on. You only need this addon if:
- Downloads from certain file hosting sites fail with "Access Denied" or it only downloads HTML error pages instead of files.
- You use premium/authenticated file hosting accounts

Without this addon:

✅ Regular downloads work fine
✅ Torrents and magnets work fine
❌ Some authenticated file hosts may fail
✅ Workaround: Disable auto-intercept and download directly in Firefox

---------------------------

Install (5 minutes)

1. Extract the .addon from the .zip to your local drive

2. Go to your Qnap web ui and open Download Station

3. Within Download Station, go ti Settings (the 3 dots located top right) → Add-on tab

4. Tap the (+) icon → Select the .addon file you extracted in #1. Download Station will install / update the addon

5. IMPORTANT: You must STOP and START the Qnap Download Station app -> Go to App Center, locate Download Station, click the dropdown → Stop → Start

6. Done! The Firefox extension will detect the Qnap addon and will now work with authenticated sites.

Supported Sites
Gofile, Mega.nz, MediaFire, RapidGator, Uploaded.net, Nitroflare, Keep2Share, 1fichier, Turbobit, PixelDrain, Catbox, and 25+ more.
