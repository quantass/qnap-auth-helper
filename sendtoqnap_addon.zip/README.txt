══════════════════════════════════════════════════════════════════════
 SEND TO QNAP++  —  Authentication Helper Add-on for Download Station
══════════════════════════════════════════════════════════════════════

──[ What is this? ]────────────────────────────────────────────────────

An optional add-on for QNAP Download Station that enables authenticated
downloads from premium file-hosting sites — Gofile, Mega, MediaFire,
and 30+ others.


──[ Do I need this? ]──────────────────────────────────────────────────

No — it's entirely optional. The Send to QNAP++ Firefox extension
already works fine for most sites without it. You only need this
add-on if:

  • A download fails with "Access Denied", or
  • Download Station grabs an HTML error page instead of the real file, or
  • You use a premium / authenticated file-hosting account

Without this add-on:

  ✓  Regular downloads          — work fine
  ✓  Torrents & magnet links    — work fine
  ✗  Some authenticated hosts   — may fail
  ✓  Workaround available       — disable auto-intercept and download
                                   directly in Firefox instead


──[ Install  ·  ~5 minutes ]───────────────────────────────────────────

  1.  Extract the .addon file from the .zip onto your computer.

  2.  Open the QNAP web UI. Open [ Download Station ].

  3.  Go to Settings (⋮ - top-right of DS). Select the "Add-on" tab.

  4.  Tap (+) → select the .addon file from step 1.
      Download Station will install / update the add-on.

  5.  ⚠ IMPORTANT — restart Download Station itself:
      App Center → Download Station → Select dropdown → Stop → Start.

  6.  Done! Firefox will detect the add-on automatically and start
      working with authenticated sites.


──[ Found a site that still fails? ]───────────────────────────────────

If a download fails through Send to QNAP++ but works as a direct
download in Firefox, email me the site + file URL — I'll add support
for it in the next update.  Email: sendtoqnapplus@gmail.com


──[ Supported sites ]──────────────────────────────────────────────────

  Gofile · Mega.nz · MediaFire · RapidGator · Uploaded.net
  Nitroflare · Keep2Share · 1fichier · Turbobit · PixelDrain
  Catbox · and 30+ more

════════════════════════════════════════════════════════════════════
